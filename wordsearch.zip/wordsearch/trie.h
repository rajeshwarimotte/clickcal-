#ifndef TRIE_H
#define TRIE_H

#define ALPHABET_SIZE 26
#define MAX_MEANING 300
#define MAX_WORD_LENGTH 50

typedef struct TrieNode {
    struct TrieNode *children[ALPHABET_SIZE];
    int isEndOfWord;
    char meaning[MAX_MEANING];
} TrieNode;

TrieNode* createNode();

void insertWord(TrieNode *root, const char *word, const char *meaning);

char* searchWord(TrieNode *root, const char *word);

void suggestWords(TrieNode *root, const char *prefix);

void freeTrie(TrieNode *root);

#endif