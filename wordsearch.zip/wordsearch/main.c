#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <winsock2.h>
#include <ws2tcpip.h>

#include "trie.h"
#include "dictionary.h"

#define PORT 8080
#define BUFFER_SIZE 8192
#define MAX_HISTORY 100

TrieNode *root;

/* Search History */
char searchHistory[MAX_HISTORY][50];
int historyCount = 0;


/* ==========================================
   FIND WORD IN DICTIONARY
========================================== */

Dictionary* findDictionaryWord(const char *word) {

    for (int i = 0; i < wordCount; i++) {

        if (words[i].word[0] == '\0')
            continue;

        if (_stricmp(words[i].word, word) == 0)
            return &words[i];
    }

    return NULL;
}


/* ==========================================
   URL DECODING
========================================== */

void urlDecode(char *destination, const char *source) {

    int i = 0;
    int j = 0;

    while (source[i] != '\0' && j < 198) {

        if (source[i] == '%' &&
            isxdigit((unsigned char)source[i + 1]) &&
            isxdigit((unsigned char)source[i + 2])) {

            char hex[3] = {
                source[i + 1],
                source[i + 2],
                '\0'
            };

            destination[j++] = (char)strtol(hex, NULL, 16);

            i += 3;
        }

        else if (source[i] == '+') {

            destination[j++] = ' ';
            i++;
        }

        else {

            destination[j++] = source[i++];
        }
    }

    destination[j] = '\0';
}
/* Save search history without duplicates */
void addHistory(const char *word) {

    int existingIndex = -1;

    /* Check whether the word already exists */
    for (int i = 0; i < historyCount; i++) {

        if (_stricmp(searchHistory[i], word) == 0) {
            existingIndex = i;
            break;
        }
    }

    /* Remove existing occurrence */
    if (existingIndex != -1) {

        for (int i = existingIndex; i < historyCount - 1; i++) {

            strcpy(
                searchHistory[i],
                searchHistory[i + 1]
            );
        }

        historyCount--;
    }

    /* Make space if history is full */
    if (historyCount >= MAX_HISTORY) {

        for (int i = 1; i < MAX_HISTORY; i++) {

            strcpy(
                searchHistory[i - 1],
                searchHistory[i]
            );
        }

        historyCount--;
    }

    /* Add searched word at the end */
    strcpy(
        searchHistory[historyCount],
        word
    );

    historyCount++;

    /* Save updated history */
    FILE *file = fopen("search_history.txt", "w");

    if (file == NULL)
        return;

    for (int i = 0; i < historyCount; i++) {

        fprintf(
            file,
            "%s\n",
            searchHistory[i]
        );
    }

    fclose(file);
}

/* ==========================================
   JSON ESCAPING
========================================== */

void jsonEscape(char *output, const char *input) {

    int j = 0;

    for (int i = 0;
         input[i] != '\0' && j < 1990;
         i++) {

        unsigned char ch = (unsigned char)input[i];

        if (ch == '"' || ch == '\\') {

            output[j++] = '\\';
            output[j++] = ch;
        }

        else if (ch == '\n') {

            output[j++] = '\\';
            output[j++] = 'n';
        }

        else if (ch == '\r') {

            output[j++] = '\\';
            output[j++] = 'r';
        }

        else if (ch == '\t') {

            output[j++] = '\\';
            output[j++] = 't';
        }

        else if (ch >= 32) {

            output[j++] = ch;
        }
    }

    output[j] = '\0';
}


/* ==========================================
   SEND HTTP RESPONSE
========================================== */

void sendResponse(
    SOCKET client,
    const char *contentType,
    const char *body,
    int status
) {

    char header[1024];

    const char *statusText =
        status == 200 ? "200 OK" :
        status == 404 ? "404 Not Found" :
        "400 Bad Request";

    snprintf(
        header,
        sizeof(header),

        "HTTP/1.1 %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %d\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Connection: close\r\n"
        "\r\n",

        statusText,
        contentType,
        (int)strlen(body)
    );

    send(client, header, (int)strlen(header), 0);

    send(client, body, (int)strlen(body), 0);
}


/* ==========================================
   LOAD SEARCH HISTORY
========================================== */

void loadHistory() {

    FILE *file = fopen("search_history.txt", "r");

    if (file == NULL)
        return;

    char line[50];

    /*
       Read the file from oldest to newest.
       If a word appears again, remove its older position
       and add it at the newest position.
       This keeps only one copy of each word.
    */
    while (fgets(line, sizeof(line), file) != NULL) {

        line[strcspn(line, "\r\n")] = '\0';

        if (line[0] == '\0')
            continue;

        int existingIndex = -1;

        for (int i = 0; i < historyCount; i++) {

            if (_stricmp(searchHistory[i], line) == 0) {
                existingIndex = i;
                break;
            }
        }

        /* Remove an older copy, if present. */
        if (existingIndex != -1) {

            for (int i = existingIndex; i < historyCount - 1; i++) {
                strcpy(searchHistory[i], searchHistory[i + 1]);
            }

            historyCount--;
        }

        /* Keep only the latest MAX_HISTORY unique words. */
        if (historyCount >= MAX_HISTORY) {

            for (int i = 1; i < MAX_HISTORY; i++) {
                strcpy(searchHistory[i - 1], searchHistory[i]);
            }

            historyCount--;
        }

        strcpy(searchHistory[historyCount], line);
        historyCount++;
    }

    fclose(file);

    /* Rewrite the file with the cleaned history. */
    file = fopen("search_history.txt", "w");

    if (file == NULL)
        return;

    for (int i = 0; i < historyCount; i++) {
        fprintf(file, "%s\n", searchHistory[i]);
    }

    fclose(file);
}


/* ==========================================
   DICTIONARY SEARCH API
========================================== */

void handleSearch(SOCKET client, const char *requestPath) {

    char encodedWord[200] = "";
    char word[200] = "";

    const char *parameter = strstr(
        requestPath,
        "word="
    );

    if (parameter == NULL) {

        sendResponse(
            client,
            "application/json",
            "{\"found\":false,\"message\":\"Please enter a word.\"}",
            400
        );

        return;
    }

    parameter += 5;

    int i = 0;

    while (
        parameter[i] != '\0' &&
        parameter[i] != '&' &&
        i < 199
    ) {

        encodedWord[i] = parameter[i];
        i++;
    }

    encodedWord[i] = '\0';

    urlDecode(word, encodedWord);

    /* Search using Trie */

    char *meaning = searchWord(root, word);

    if (meaning == NULL) {

        sendResponse(
            client,
            "application/json",
            "{\"found\":false,\"message\":\"Word not found.\"}",
            200
        );

        return;
    }

    /* Find complete dictionary record */

    Dictionary *item = findDictionaryWord(word);

    if (item == NULL) {

        sendResponse(
            client,
            "application/json",
            "{\"found\":false,\"message\":\"Word not found.\"}",
            200
        );

        return;
    }

    /* Save successful search */

    addHistory(item->word);

    /* Escape dictionary data */

    char safeWord[2000];
    char safeMeaning[2000];
    char safePOS[2000];
    char safeExample[2000];
    char safeSynonym[2000];
    char safeAntonym[2000];

    jsonEscape(safeWord, item->word);

    jsonEscape(safeMeaning, item->meaning);

    jsonEscape(safePOS, item->partOfSpeech);

    jsonEscape(safeExample, item->example);

    jsonEscape(safeSynonym, item->synonym);

    jsonEscape(safeAntonym, item->antonym);

    /* Create JSON response */

    char json[12000];

    snprintf(
        json,
        sizeof(json),

        "{"
        "\"found\":true,"
        "\"word\":\"%s\","
        "\"meaning\":\"%s\","
        "\"partOfSpeech\":\"%s\","
        "\"example\":\"%s\","
        "\"synonym\":\"%s\","
        "\"antonym\":\"%s\""
        "}",

        safeWord,
        safeMeaning,
        safePOS,
        safeExample,
        safeSynonym,
        safeAntonym
    );

    sendResponse(
        client,
        "application/json",
        json,
        200
    );
}


/* ==========================================
   FIND PREFIX IN TRIE
========================================== */

TrieNode* findPrefixNode(const char *prefix) {

    TrieNode *current = root;

    for (int i = 0; prefix[i] != '\0'; i++) {

        char ch = (char)tolower(
            (unsigned char)prefix[i]
        );

        if (ch < 'a' || ch > 'z')
            return NULL;

        int index = ch - 'a';

        if (current->children[index] == NULL)
            return NULL;

        current = current->children[index];
    }

    return current;
}


/* ==========================================
   COLLECT WORD SUGGESTIONS
========================================== */

void collectSuggestions(
    TrieNode *node,
    char *word,
    int level,
    char *json,
    int *count,
    int *length
) {

    if (node == NULL || *count >= 10)
        return;

    if (node->isEndOfWord) {

        word[level] = '\0';

        char safeWord[200];

        jsonEscape(safeWord, word);

        int remaining = 8192 - *length;

        int written = snprintf(
            json + *length,
            remaining,

            "%s\"%s\"",

            *count == 0 ? "" : ",",
            safeWord
        );

        if (written < 0 || written >= remaining)
            return;

        *length += written;

        (*count)++;
    }

    for (
        int i = 0;
        i < ALPHABET_SIZE && *count < 10;
        i++
    ) {

        if (node->children[i] != NULL) {

            word[level] = 'a' + i;

            collectSuggestions(
                node->children[i],
                word,
                level + 1,
                json,
                count,
                length
            );
        }
    }
}


/* ==========================================
   LIVE WORD SUGGESTIONS API
========================================== */

void handleSuggestions(
    SOCKET client,
    const char *requestPath
) {

    char encodedPrefix[200] = "";
    char prefix[200] = "";

    const char *parameter = strstr(
        requestPath,
        "prefix="
    );

    if (parameter == NULL) {

        sendResponse(
            client,
            "application/json",
            "{\"suggestions\":[]}",
            200
        );

        return;
    }

    parameter += 7;

    int i = 0;

    while (
        parameter[i] != '\0' &&
        parameter[i] != '&' &&
        i < 199
    ) {

        encodedPrefix[i] = parameter[i];
        i++;
    }

    encodedPrefix[i] = '\0';

    urlDecode(prefix, encodedPrefix);

    /* Empty prefix */

    if (prefix[0] == '\0') {

        sendResponse(
            client,
            "application/json",
            "{\"suggestions\":[]}",
            200
        );

        return;
    }

    /* Find matching Trie node */

    TrieNode *node = findPrefixNode(prefix);

    char json[8192] = "{\"suggestions\":[";

    int length = strlen(json);

    int count = 0;

    if (
        node != NULL &&
        strlen(prefix) < MAX_WORD_LENGTH
    ) {

        char word[MAX_WORD_LENGTH];

        strcpy(word, prefix);

        collectSuggestions(
            node,
            word,
            (int)strlen(word),
            json,
            &count,
            &length
        );
    }

    snprintf(
        json + length,
        sizeof(json) - length,
        "]}"
    );

    sendResponse(
        client,
        "application/json",
        json,
        200
    );
}


/* ==========================================
   SEARCH HISTORY API
========================================== */

void handleHistory(SOCKET client) {

    char json[8192] = "{\"history\":[";

    int length = strlen(json);

    for (int i = historyCount - 1; i >= 0; i--) {

        char safeWord[200];

        jsonEscape(
            safeWord,
            searchHistory[i]
        );

        int remaining = sizeof(json) - length;

        int written = snprintf(
            json + length,
            remaining,

            "%s\"%s\"",

            i == historyCount - 1 ? "" : ",",
            safeWord
        );

        if (written < 0 || written >= remaining)
            break;

        length += written;
    }

    snprintf(
        json + length,
        sizeof(json) - length,
        "]}"
    );

    sendResponse(
        client,
        "application/json",
        json,
        200
    );
}


/* ==========================================
   SERVE FRONTEND FILES
========================================== */

void serveFile(
    SOCKET client,
    const char *filename,
    const char *contentType
) {

    FILE *file = fopen(filename, "rb");

    if (file == NULL) {

        sendResponse(
            client,
            "text/plain",
            "File not found.",
            404
        );

        return;
    }

    char *content = malloc(500000);

    if (content == NULL) {

        fclose(file);

        return;
    }

    size_t fileLength = fread(
        content,
        1,
        499999,
        file
    );

    content[fileLength] = '\0';

    fclose(file);

    char header[1024];

    snprintf(
        header,
        sizeof(header),

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "\r\n",

        contentType,
        fileLength
    );

    send(
        client,
        header,
        (int)strlen(header),
        0
    );

    size_t sent = 0;

    while (sent < fileLength) {

        int result = send(
            client,
            content + sent,
            (int)(fileLength - sent),
            0
        );

        if (result <= 0)
            break;

        sent += result;
    }

    free(content);
}


/* ==========================================
   MAIN SERVER
========================================== */

int main() {

    WSADATA wsa;

    /* Initialize Winsock */

    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {

        printf("Winsock initialization failed!\n");

        return 1;
    }

    /* Create Trie */

    root = createNode();

    /* Load dictionary into Trie */

    for (int i = 0; i < wordCount; i++) {

        if (words[i].word[0] != '\0') {

            insertWord(
                root,
                words[i].word,
                words[i].meaning
            );
        }
    }

    /* Load previous search history */

    loadHistory();

    /* Create server socket */

    SOCKET server = socket(
        AF_INET,
        SOCK_STREAM,
        0
    );

    if (server == INVALID_SOCKET) {

        printf("Socket creation failed!\n");

        freeTrie(root);

        WSACleanup();

        return 1;
    }

    /* Server address */

    struct sockaddr_in serverAddress;

    memset(
        &serverAddress,
        0,
        sizeof(serverAddress)
    );

    serverAddress.sin_family = AF_INET;

    serverAddress.sin_addr.s_addr =
        inet_addr("127.0.0.1");

    serverAddress.sin_port = htons(PORT);

    /* Bind server */

    if (
        bind(
            server,
            (struct sockaddr*)&serverAddress,
            sizeof(serverAddress)
        ) == SOCKET_ERROR
    ) {

        printf("Port %d is unavailable!\n", PORT);

        closesocket(server);

        freeTrie(root);

        WSACleanup();

        return 1;
    }

    /* Start listening */

    if (listen(server, 10) == SOCKET_ERROR) {

        printf("Server could not start!\n");

        closesocket(server);

        freeTrie(root);

        WSACleanup();

        return 1;
    }

    /* Server information */

    printf("\n====================================\n");

    printf("          WORDSEARCH SERVER\n");

    printf("====================================\n");

    printf(
        "Dictionary entries loaded: %d\n",
        wordCount
    );

    printf(
        "Previous searches loaded: %d\n",
        historyCount
    );

    printf("\nServer running at:\n");

    printf("http://127.0.0.1:8080\n");

    printf("\nPress Ctrl+C to stop the server.\n");


    /* ======================================
       HANDLE CLIENT REQUESTS
    ====================================== */

    while (1) {

        SOCKET client = accept(
            server,
            NULL,
            NULL
        );

        if (client == INVALID_SOCKET)
            continue;

        char request[BUFFER_SIZE];

        int received = recv(
            client,
            request,
            sizeof(request) - 1,
            0
        );

        if (received <= 0) {

            closesocket(client);

            continue;
        }

        request[received] = '\0';

        char method[10];

        char path[2048];

        if (
            sscanf(
                request,
                "%9s %2047s",
                method,
                path
            ) != 2
        ) {

            closesocket(client);

            continue;
        }

        /* GET requests only */

        if (strcmp(method, "GET") != 0) {

            sendResponse(
                client,
                "text/plain",
                "Method not supported.",
                400
            );
        }

        /* Dictionary search */

        else if (
            strncmp(path, "/api/search?", 12) == 0
        ) {

            handleSearch(client, path);
        }

        /* Live suggestions */

        else if (
            strncmp(path, "/api/suggest?", 13) == 0
        ) {

            handleSuggestions(client, path);
        }

        /* Search history */

        else if (
            strcmp(path, "/api/history") == 0
        ) {

            handleHistory(client);
        }

        /* Home page */

        else if (
            strcmp(path, "/") == 0 ||
            strcmp(path, "/index.html") == 0
        ) {

            serveFile(
                client,
                "frontend/index.html",
                "text/html"
            );
        }

        /* CSS */

        else if (
            strcmp(path, "/style.css") == 0
        ) {

            serveFile(
                client,
                "frontend/style.css",
                "text/css"
            );
        }

        /* JavaScript */

        else if (
            strcmp(path, "/script.js") == 0
        ) {

            serveFile(
                client,
                "frontend/script.js",
                "application/javascript"
            );
        }

        /* Unknown route */

        else {

            sendResponse(
                client,
                "text/plain",
                "Page not found.",
                404
            );
        }

        closesocket(client);
    }

    /* Cleanup */

    closesocket(server);

    freeTrie(root);

    WSACleanup();

    return 0;
}