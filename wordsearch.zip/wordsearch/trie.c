#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "trie.h"

TrieNode* createNode() {

    TrieNode *node = (TrieNode*)malloc(sizeof(TrieNode));

    if (node == NULL) {
        printf("Memory allocation failed!");
        exit(1);
    }

    node->isEndOfWord = 0;
    node->meaning[0] = '\0';

    for (int i = 0; i < ALPHABET_SIZE; i++) {
        node->children[i] = NULL;
    }

    return node;
}

void insertWord(TrieNode *root, const char *word, const char *meaning) {

    TrieNode *current = root;

    for (int i = 0; word[i] != '\0'; i++) {

        char ch = tolower((unsigned char)word[i]);

        if (ch < 'a' || ch > 'z')
            return;

        int index = ch - 'a';

        if (current->children[index] == NULL)
            current->children[index] = createNode();

        current = current->children[index];
    }

    current->isEndOfWord = 1;

    strncpy(current->meaning, meaning, MAX_MEANING - 1);
    current->meaning[MAX_MEANING - 1] = '\0';
}

char* searchWord(TrieNode *root, const char *word) {

    TrieNode *current = root;

    for (int i = 0; word[i] != '\0'; i++) {

        char ch = tolower((unsigned char)word[i]);

        if (ch < 'a' || ch > 'z')
            return NULL;

        int index = ch - 'a';

        if (current->children[index] == NULL)
            return NULL;

        current = current->children[index];
    }

    return current->isEndOfWord ? current->meaning : NULL;
}

// Display words stored below a prefix
void displaySuggestions(TrieNode *node, char *word, int level, int *count) {

    if (node == NULL || *count >= 10)
        return;

    if (node->isEndOfWord) {

        word[level] = '\0';

        printf("%d. %s\n", *count + 1, word);

        (*count)++;
    }

    for (int i = 0; i < ALPHABET_SIZE && *count < 10; i++) {

        if (node->children[i] != NULL) {

            word[level] = 'a' + i;

            displaySuggestions(
                node->children[i],
                word,
                level + 1,
                count
            );
        }
    }
}

// Find words beginning with the entered prefix
void suggestWords(TrieNode *root, const char *prefix) {

    TrieNode *current = root;

    char word[MAX_WORD_LENGTH];

    int length = 0;

    while (prefix[length] != '\0') {

        char ch = tolower((unsigned char)prefix[length]);

        if (ch < 'a' || ch > 'z') {
            printf("\nPlease enter letters only.\n");
            return;
        }

        int index = ch - 'a';

        if (current->children[index] == NULL) {
            printf("\nNo suggestions found!\n");
            return;
        }

        current = current->children[index];

        if (length >= MAX_WORD_LENGTH - 1) {
            printf("\nPrefix is too long.\n");
            return;
        }

        word[length] = ch;
        length++;
    }

    word[length] = '\0';

    int count = 0;

    printf("\nWord Suggestions:\n");
    displaySuggestions(current, word, length, &count);

    if (count == 0) {
        printf("No suggestions found!\n");
    }
}

// Free Trie memory
void freeTrie(TrieNode *root) {

    if (root == NULL)
        return;

    for (int i = 0; i < ALPHABET_SIZE; i++) {
        freeTrie(root->children[i]);
    }

    free(root);
}