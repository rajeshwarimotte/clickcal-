const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const searchResult = document.getElementById("searchResult");

const suggestionBox = document.getElementById("suggestionBox");

const historyButton = document.getElementById("historyButton");
const historyPanel = document.getElementById("historyPanel");


// ===================================
// LIVE WORD SUGGESTIONS
// ===================================

let suggestionTimer;

searchInput.addEventListener("input", function () {

    clearTimeout(suggestionTimer);

    const prefix = searchInput.value.trim();

    suggestionBox.replaceChildren();

    if (!prefix) {
        suggestionBox.style.display = "none";
        return;
    }

    suggestionTimer = setTimeout(async function () {

        try {

            const response = await fetch(
                `/api/suggest?prefix=${encodeURIComponent(prefix)}`
            );

            const data = await response.json();

            suggestionBox.replaceChildren();

            if (!data.suggestions || data.suggestions.length === 0) {

                suggestionBox.style.display = "none";
                return;
            }

            data.suggestions.forEach(word => {

                const item = document.createElement("button");

                item.type = "button";
                item.className = "suggestion-item";
                item.textContent = word;

                item.addEventListener("click", function () {

                    searchInput.value = word;

                    suggestionBox.style.display = "none";

                    searchForm.requestSubmit();

                });

                suggestionBox.appendChild(item);

            });

            suggestionBox.style.display = "block";

        }

        catch (error) {

            console.error("Suggestion error:", error);

        }

    }, 150);

});


// Hide suggestions when clicking outside

document.addEventListener("click", function (event) {

    if (
        !searchForm.contains(event.target) &&
        !suggestionBox.contains(event.target)
    ) {
        suggestionBox.style.display = "none";
    }

});


// ===================================
// DICTIONARY SEARCH
// ===================================

searchForm.addEventListener("submit", async function (event) {

    event.preventDefault();

    const word = searchInput.value.trim();

    if (!word) return;

    suggestionBox.style.display = "none";

    searchResult.innerHTML = `
        <div class="empty-state">
            <h3>Searching...</h3>
            <p>Please wait while we find your word.</p>
        </div>
    `;

    try {

        const response = await fetch(
            `/api/search?word=${encodeURIComponent(word)}`
        );

        const data = await response.json();

        if (!data.found) {

            searchResult.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">🔍</div>
                    <h3>Word Not Found</h3>
                    <p>This word is not available in our dictionary.</p>
                </div>
            `;

            return;
        }

        const card = document.createElement("div");

        card.className = "word-card";

        const title = document.createElement("h2");

        title.className = "word-title";
        title.textContent = data.word;

        const pos = document.createElement("span");

        pos.className = "word-pos";
        pos.textContent = data.partOfSpeech || "-";

        card.appendChild(title);
        card.appendChild(pos);


        function addDetail(title, value) {

            const block = document.createElement("div");

            block.className = "detail-block";

            const heading = document.createElement("h4");

            heading.textContent = title;

            const paragraph = document.createElement("p");

            paragraph.textContent = value || "-";

            block.appendChild(heading);
            block.appendChild(paragraph);

            card.appendChild(block);

        }

        addDetail("Meaning", data.meaning);

        addDetail("Example Sentence", data.example);

        addDetail("Synonyms", data.synonym);

        addDetail("Antonyms", data.antonym);

        searchResult.replaceChildren(card);

    }

    catch (error) {

        searchResult.innerHTML = `
            <div class="empty-state">
                <h3>Connection Error</h3>
                <p>Unable to connect to WordSearch server.</p>
                <p>Please make sure your C server is running.</p>
            </div>
        `;

        console.error(error);

    }

});


//===================================
// SEARCH HISTORY
// ===================================

historyButton.addEventListener("click", async function () {

    if (historyPanel.style.display === "block") {
        historyPanel.style.display = "none";
        return;
    }

    historyPanel.style.display = "block";
    historyPanel.replaceChildren();

    try {

        const response = await fetch("/api/history");
        const data = await response.json();

        const heading = document.createElement("h3");
        heading.textContent = "Recently Searched Words";

        historyPanel.appendChild(heading);

        if (!data.history || data.history.length === 0) {

            const message = document.createElement("p");
            message.textContent = "No search history available.";

            historyPanel.appendChild(message);
            return;
        }

        const list = document.createElement("ul");
        list.className = "history-list";

        data.history.forEach(word => {

            const listItem = document.createElement("li");

            const button = document.createElement("button");

            button.type = "button";
            button.className = "history-item";
            button.textContent = word;

            button.addEventListener("click", function () {

                searchInput.value = word;
                historyPanel.style.display = "none";

                searchForm.requestSubmit();

            });

            listItem.appendChild(button);
            list.appendChild(listItem);

        });

        historyPanel.appendChild(list);

    }

    catch (error) {

        historyPanel.textContent =
            "Unable to load search history.";

        console.error(error);

    }

});
