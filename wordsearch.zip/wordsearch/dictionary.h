#ifndef DICTIONARY_H
#define DICTIONARY_H

#define MAX_WORDS 500

typedef struct {
    char word[50];
    char meaning[250];
    char example[250];
    char partOfSpeech[30];
    char synonym[100];
    char antonym[100];
} Dictionary;

extern Dictionary words[MAX_WORDS];
extern int wordCount;

#endif