#include <stdio.h>

int main() {

    printf("\n================================\n");
    printf("       WORDSEARCH PROJECT\n");
    printf("================================\n");

    printf("\nHello! My project is running.\n");

    printf("\nPress Enter to exit...");
    getchar();

    return 0;
}