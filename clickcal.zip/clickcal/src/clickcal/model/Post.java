package clickcal.model;

public class Post {

private String photographer;
private String specialization;
private String description;
private String category;
private String imagePath;

public Post(String photographer,
            String specialization,
            String description,
            String category,
            String imagePath) {

    this.photographer = photographer;
    this.specialization = specialization;
    this.description = description;
    this.category = category;
    this.imagePath = imagePath;
}

public String getPhotographer() {
    return photographer;
}

public String getSpecialization() {
    return specialization;
}

public String getDescription() {
    return description;
}

public String getCategory() {
    return category;
}

public String getImagePath() {
    return imagePath;
}


}
