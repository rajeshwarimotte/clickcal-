package clickcal.model;

import java.util.ArrayList;
import java.util.List;

public class ReviewData {

    private static final List<Review> reviews =
            new ArrayList<>();

    public static void addReview(int reviewId,
            String clientName, String eventType,
            int rating, String comment, String reviewDate) {

        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException(
                    "Rating must be between 1 and 5."
            );
        }

        Review review = new Review(
                reviewId, clientName, eventType,
                rating, comment, reviewDate
        );

        reviews.add(review);
    }

    public static List<Review> getReviews() {
        return new ArrayList<>(reviews);
    }

    public static double getAverageRating() {

        if (reviews.isEmpty()) {
            return 0.0;
        }

        int total = 0;

        for (Review review : reviews) {
            total += review.getRating();
        }

        return (double) total / reviews.size();
    }

    public static int getTotalReviews() {
        return reviews.size();
    }
}