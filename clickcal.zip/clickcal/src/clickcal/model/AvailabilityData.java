package clickcal.model;

import java.util.HashMap;
import java.util.Map;

public class AvailabilityData {

    private static final Map<String, String> availability =
            new HashMap<>();

    public static void setStatus(String date, String slot, String status) {

        availability.put(date + "_" + slot, status);
    }

    public static String getStatus(String date, String slot) {

        return availability.getOrDefault(
                date + "_" + slot, "Available"
        );
    }

    public static Map<String, String> getAll() {

        return availability;
    }
}