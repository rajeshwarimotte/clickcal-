package clickcal.model;

import java.util.ArrayList;
import java.util.List;

public class BookingData {

    private static final List<Booking> bookings =
            new ArrayList<>();

    private static int nextId = 1;

    public static void addBooking(String clientName,
            String packageName, String eventDate,
            String timeSlot, String location) {

        Booking booking = new Booking(
                nextId++,
                clientName,
                packageName,
                eventDate,
                timeSlot,
                location
        );

        bookings.add(booking);
    }

    public static List<Booking> getBookings() {
        return bookings;
    }

    public static void updateStatus(int bookingId,
            String status) {

        for (Booking booking : bookings) {

            if (booking.getBookingId() == bookingId) {
                booking.setStatus(status);
                break;
            }
        }
    }
}