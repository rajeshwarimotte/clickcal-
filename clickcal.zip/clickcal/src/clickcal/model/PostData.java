package clickcal.model;

import java.util.ArrayList;
import java.util.List;

public class PostData {

    private static final List<Post> posts = new ArrayList<>();

    public static void addPost(String photographer, String specialization,
            String description, String category, String imagePath) {

        Post post = new Post(
            photographer,
            specialization,
            description,
            category,
            imagePath
        );

        posts.add(0, post);
    }

    public static List<Post> getPosts() {
        return posts;
    }
}