package clickcal.model;

public class Booking {

    private int bookingId;
    private String clientName;
    private String packageName;
    private String eventDate;
    private String timeSlot;
    private String location;
    private String status;

    public Booking(int bookingId, String clientName,
            String packageName, String eventDate,
            String timeSlot, String location) {

        this.bookingId = bookingId;
        this.clientName = clientName;
        this.packageName = packageName;
        this.eventDate = eventDate;
        this.timeSlot = timeSlot;
        this.location = location;
        this.status = "Pending";
    }

    public int getBookingId() {
        return bookingId;
    }

    public String getClientName() {
        return clientName;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public String getLocation() {
        return location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}