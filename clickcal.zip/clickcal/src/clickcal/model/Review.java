package clickcal.model;

public class Review {

    private int reviewId;
    private String clientName;
    private String eventType;
    private int rating;
    private String comment;
    private String reviewDate;

    public Review(int reviewId, String clientName,
            String eventType, int rating,
            String comment, String reviewDate) {

        this.reviewId = reviewId;
        this.clientName = clientName;
        this.eventType = eventType;
        this.rating = rating;
        this.comment = comment;
        this.reviewDate = reviewDate;
    }

    public int getReviewId() {
        return reviewId;
    }

    public String getClientName() {
        return clientName;
    }

    public String getEventType() {
        return eventType;
    }

    public int getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    public String getReviewDate() {
        return reviewDate;
    }
}