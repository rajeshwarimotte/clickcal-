package clickcal;

import javax.swing.*;

import clickcal.ui.LoginPage;

public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            try {

                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
                );

            } catch (Exception e) {

                e.printStackTrace();

            }

            new LoginPage().setVisible(true);

        });
    }
}