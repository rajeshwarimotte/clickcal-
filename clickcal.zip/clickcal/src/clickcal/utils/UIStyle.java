package clickcal.utils;

import java.awt.*;

public class UIStyle {


public static final Color BACKGROUND =
        new Color(243, 242, 239);

public static final Color WHITE =
        Color.WHITE;

public static final Color PRIMARY =
        new Color(35, 55, 75);

public static final Color ACCENT =
        new Color(181, 145, 91);

public static final Color TEXT =
        new Color(45, 45, 45);

public static final Color SECONDARY =
        new Color(110, 110, 110);

public static final Font HEADING =
        new Font("SansSerif", Font.BOLD, 22);

public static final Font NORMAL =
        new Font("SansSerif", Font.PLAIN, 14);

public static final Font SMALL =
        new Font("SansSerif", Font.PLAIN, 12);


}
