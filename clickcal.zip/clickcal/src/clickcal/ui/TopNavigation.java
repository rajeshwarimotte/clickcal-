package clickcal.ui;

import javax.swing.*;
import java.awt.*;
import clickcal.utils.UIStyle;

public class TopNavigation extends JPanel {

public TopNavigation() {

    setLayout(new BorderLayout());
    setBackground(Color.WHITE);
    setPreferredSize(new Dimension(100, 70));

    JLabel logo = new JLabel("  ClickCal");
    logo.setFont(new Font("SansSerif", Font.BOLD, 25));
    logo.setForeground(UIStyle.PRIMARY);

    add(logo, BorderLayout.WEST);

    JPanel navigation = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 20, 20)
    );

    navigation.setBackground(Color.WHITE);

    String[] items = {
        "Home", "Explore", "Categories",
        "Bookings", "Notifications", "Profile"
    };

    for (String item : items) {

        JButton button = new JButton(item);

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFont(UIStyle.NORMAL);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        navigation.add(button);
    }

    add(navigation, BorderLayout.EAST);
}

}
