package clickcal.ui;

import javax.swing.*;
import java.awt.*;

import clickcal.model.Post;
import clickcal.model.PostData;

public class PortfolioPage extends JPanel {

    private JPanel portfolioPanel;

    public PortfolioPage() {

        setLayout(new BorderLayout());
        setBackground(new Color(243, 242, 239));

        // HEADING

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);

        header.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        JLabel title = new JLabel("My Photography Portfolio");

        title.setFont(
            new Font("SansSerif", Font.BOLD, 23)
        );

        header.add(title, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // PORTFOLIO CONTENT

        portfolioPanel = new JPanel();

        portfolioPanel.setLayout(
            new BoxLayout(portfolioPanel, BoxLayout.Y_AXIS)
        );

        portfolioPanel.setBackground(
            new Color(243, 242, 239)
        );

        portfolioPanel.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        refreshPortfolio();

        JScrollPane scroll = new JScrollPane(portfolioPanel);

        scroll.setBorder(null);

        scroll.getVerticalScrollBar().setUnitIncrement(18);

        add(scroll, BorderLayout.CENTER);
    }

    public void refreshPortfolio() {

        portfolioPanel.removeAll();

        if (PostData.getPosts().isEmpty()) {

            JLabel empty = new JLabel(
                "You haven't uploaded any photographs yet."
            );

            empty.setFont(
                new Font("SansSerif", Font.PLAIN, 16)
            );

            portfolioPanel.add(empty);

        } else {

            for (Post post : PostData.getPosts()) {

                portfolioPanel.add(new PostCard(post));

                portfolioPanel.add(
                    Box.createVerticalStrut(15)
                );
            }
        }

        portfolioPanel.revalidate();
        portfolioPanel.repaint();
    }
}

