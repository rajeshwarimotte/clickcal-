package clickcal.ui;

import clickcal.model.Review;
import clickcal.model.ReviewData;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PhotographerReviews extends JPanel {

    private DefaultTableModel model;
    private JLabel ratingLabel;
    private JLabel countLabel;

    public PhotographerReviews() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(243, 242, 239));

        setBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        // HEADING

        JLabel heading = new JLabel("My Reviews");

        heading.setFont(
                new Font("SansSerif", Font.BOLD, 26)
        );

        add(heading, BorderLayout.NORTH);

        // RATING SUMMARY

        JPanel summary = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 40, 15)
        );

        summary.setBackground(Color.WHITE);

        ratingLabel = new JLabel();
        ratingLabel.setFont(
                new Font("SansSerif", Font.BOLD, 22)
        );

        countLabel = new JLabel();
        countLabel.setFont(
                new Font("SansSerif", Font.PLAIN, 16)
        );

        summary.add(ratingLabel);
        summary.add(countLabel);

        // TABLE

        String[] columns = {
            "Review ID",
            "Client Name",
            "Event Type",
            "Rating",
            "Comment",
            "Date"
        };

        model = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);

        table.setRowHeight(35);
        table.setFont(
                new Font("SansSerif", Font.PLAIN, 13)
        );

        table.getTableHeader().setFont(
                new Font("SansSerif", Font.BOLD, 13)
        );

        JScrollPane scroll = new JScrollPane(table);

        // MAIN CONTENT

        JPanel center = new JPanel(new BorderLayout(10, 15));

        center.setBackground(new Color(243, 242, 239));

        center.add(summary, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(center, BorderLayout.CENTER);

        // REFRESH BUTTON

        JButton refreshButton = new JButton("Refresh Reviews");

        refreshButton.addActionListener(
                e -> loadReviews()
        );

        JPanel bottom = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );

        bottom.setBackground(new Color(243, 242, 239));
        bottom.add(refreshButton);

        add(bottom, BorderLayout.SOUTH);

        loadReviews();
    }

    private void loadReviews() {

        model.setRowCount(0);

        for (Review review : ReviewData.getReviews()) {

            String stars = "*".repeat(review.getRating());

            model.addRow(new Object[]{
                review.getReviewId(),
                review.getClientName(),
                review.getEventType(),
                stars,
                review.getComment(),
                review.getReviewDate()
            });
        }

        ratingLabel.setText(
                "Average Rating: "
                + String.format("%.1f", ReviewData.getAverageRating())
                + " / 5"
        );

        countLabel.setText(
                "Total Reviews: " + ReviewData.getTotalReviews()
        );
    }
}