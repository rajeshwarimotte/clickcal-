package clickcal.ui;

import javax.swing.*;
import java.awt.*;
import clickcal.utils.UIStyle;

public class LeftSidebar extends JPanel {

    public LeftSidebar() {

        setPreferredSize(new Dimension(230, 600));
        setBackground(Color.WHITE);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        setBorder(
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        );

        JLabel profile = new JLabel("DEMO CLIENT");
        profile.setFont(new Font("SansSerif", Font.BOLD, 18));
        profile.setForeground(UIStyle.PRIMARY);

        JLabel location = new JLabel("Hyderabad, India");
        location.setForeground(UIStyle.SECONDARY);

        add(profile);
        add(Box.createVerticalStrut(8));
        add(location);

        add(Box.createVerticalStrut(25));
        add(new JSeparator());
        add(Box.createVerticalStrut(20));

        String[] options = {
            "My Profile",
            "My Bookings",
            "Saved Photographers",
            "Recently Viewed",
            "Settings"
        };

        for (String option : options) {

            JButton button = new JButton(option);

            button.setAlignmentX(Component.LEFT_ALIGNMENT);
            button.setMaximumSize(new Dimension(200, 40));
            button.setBackground(Color.WHITE);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setHorizontalAlignment(SwingConstants.LEFT);

            button.addActionListener(e -> openPage(option));

            add(button);
            add(Box.createVerticalStrut(8));
        }
    }

    private void openPage(String page) {

        switch (page) {

            case "My Profile":
                JOptionPane.showMessageDialog(
                    this, 
                    "Client Profile page will be implemented next."
                );
                break;

            case "My Bookings":
                JOptionPane.showMessageDialog(
                    this, "Your bookings will appear here."
                );
                break;

            case "Saved Photographers":
                JOptionPane.showMessageDialog(
                    this, "Your saved photographers will appear here."
                );
                break;

            case "Recently Viewed":
                JOptionPane.showMessageDialog(
                    this, "Recently viewed photographers will appear here."
                );
                break;

            case "Settings":
                JOptionPane.showMessageDialog(
                    this, "Settings page will be implemented next."
                );
                break;
        }
    }
}

