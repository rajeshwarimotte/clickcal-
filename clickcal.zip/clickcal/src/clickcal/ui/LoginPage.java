package clickcal.ui;

import javax.swing.*;
import java.awt.*;

public class LoginPage extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;

    public LoginPage() {

        setTitle("ClickCal - Welcome");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(1, 2));

        // LEFT PANEL

        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(new Color(35, 55, 75));

        JLabel brand = new JLabel(
            "<html><center>ClickCal<br><br>"
            + "<font size='5'>Every Moment Deserves<br>"
            + "a Beautiful Frame.</font></center></html>"
        );

        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("SansSerif", Font.BOLD, 32));

        leftPanel.add(brand);

        // RIGHT PANEL

        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);

        JPanel form = new JPanel();

        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(Color.WHITE);

        form.setBorder(
            BorderFactory.createEmptyBorder(30, 35, 30, 35)
        );

        JLabel heading = new JLabel("Welcome to ClickCal");
        heading.setFont(new Font("SansSerif", Font.BOLD, 27));
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(
            "Discover photographers. Capture memories."
        );
        subtitle.setForeground(Color.GRAY);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel roleLabel = new JLabel("Account Type");
        roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        roleBox = new JComboBox<>(
            new String[]{"Client", "Photographer"}
        );
        roleBox.setMaximumSize(new Dimension(350, 40));
        roleBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel emailLabel = new JLabel("Email Address");
        emailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        emailField = new JTextField();
        emailField.setMaximumSize(new Dimension(350, 40));
        emailField.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        passwordField = new JPasswordField();
        passwordField.setMaximumSize(new Dimension(350, 40));
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // LOGIN BUTTON

        JButton loginButton = new JButton("Sign In");

        loginButton.setFont(
            new Font("SansSerif", Font.BOLD, 15)
        );

        loginButton.setBackground(new Color(35, 55, 75));
        loginButton.setForeground(Color.WHITE);

        loginButton.setOpaque(true);
        loginButton.setContentAreaFilled(true);
        loginButton.setBorderPainted(false);
        loginButton.setFocusPainted(false);

        loginButton.setMaximumSize(new Dimension(350, 42));
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        // REGISTER BUTTON

        JButton registerButton = new JButton("Create New Account");

        registerButton.setFont(
            new Font("SansSerif", Font.PLAIN, 14)
        );

        registerButton.setMaximumSize(new Dimension(350, 42));
        registerButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        // FORM COMPONENTS

        form.add(heading);
        form.add(Box.createVerticalStrut(10));

        form.add(subtitle);
        form.add(Box.createVerticalStrut(35));

        form.add(roleLabel);
        form.add(Box.createVerticalStrut(8));

        form.add(roleBox);
        form.add(Box.createVerticalStrut(20));

        form.add(emailLabel);
        form.add(Box.createVerticalStrut(8));

        form.add(emailField);
        form.add(Box.createVerticalStrut(20));

        form.add(passwordLabel);
        form.add(Box.createVerticalStrut(8));

        form.add(passwordField);
        form.add(Box.createVerticalStrut(30));

        form.add(loginButton);
        form.add(Box.createVerticalStrut(15));

        form.add(registerButton);

        rightPanel.add(form);

        add(leftPanel);
        add(rightPanel);

        // LOGIN ACTION

        loginButton.addActionListener(e -> login());

        // REGISTER ACTION

        registerButton.addActionListener(e -> register());
    }
    // EMAIL VALIDATION

    private boolean isValidEmail(String email) {

        String emailRegex =
            "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        return email.matches(emailRegex);
    }
    // LOGIN METHOD
    // LOGIN METHOD

private void login() {

    String email = emailField.getText().trim();

    String password = new String(
        passwordField.getPassword()
    );

    String role = (String) roleBox.getSelectedItem();

    if (email.isEmpty() || password.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter your email and password."
        );

        return;
    }

    if (!isValidEmail(email)) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid email address.\nExample: name@gmail.com",
            "Invalid Email",
            JOptionPane.ERROR_MESSAGE
        );

        return;
    }

    JOptionPane.showMessageDialog(
        this,
        "Demo access: " + role
        + "\nReal authentication will be implemented later."
    );

    openDashboard(role);
}
    
    // REGISTER METHOD

    private void register() {

        String role = (String) roleBox.getSelectedItem();

        JTextField nameField = new JTextField(20);
        JTextField email = new JTextField(20);
        JPasswordField password = new JPasswordField(20);

        Object[] fields = {
            "Full Name:", nameField,
            "Email:", email,
            "Password:", password,
            "Account Type:", role
        };

        int result = JOptionPane.showConfirmDialog(
            this,
            fields,
            "Create ClickCal Account",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        //register
        if (result == JOptionPane.OK_OPTION) {

        if (nameField.getText().trim().isEmpty()
                || email.getText().trim().isEmpty()
                || password.getPassword().length == 0) {

            JOptionPane.showMessageDialog(
                this,
                "Please fill in all fields."
            );

            return;
        }

    // EMAIL VALIDATION

        if (!isValidEmail(email.getText().trim())) {

            JOptionPane.showMessageDialog(
                this,
                "Please enter a valid email address.\nExample: name@gmail.com",
                "Invalid Email",
                JOptionPane.ERROR_MESSAGE
            );

        return;
        }

        JOptionPane.showMessageDialog(
            this,
            "Registration UI demonstration completed.\n"
            + "Database registration will be implemented in Phase 2."
        );

        openDashboard(role);
        }
    }

    // DASHBOARD NAVIGATION

    private void openDashboard(String role) {

        dispose();

        if (role.equals("Client")) {

            new HomePage().setVisible(true);

        } else {

            new PhotographerHomePage().setVisible(true);

        }
    }
}