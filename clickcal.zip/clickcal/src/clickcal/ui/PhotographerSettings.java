package clickcal.ui;

import javax.swing.*;
import java.awt.*;

public class PhotographerSettings extends JPanel {

    private JCheckBox bookingNotifications;
    private JCheckBox reviewNotifications;
    private JCheckBox profileVisibility;

    public PhotographerSettings() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(243, 242, 239));

        setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        // PAGE HEADING

        JLabel heading = new JLabel("Account Settings");

        heading.setFont(
            new Font("SansSerif", Font.BOLD, 26)
        );

        add(heading, BorderLayout.NORTH);

        // MAIN SETTINGS PANEL

        JPanel settingsPanel = new JPanel();

        settingsPanel.setLayout(
            new BoxLayout(settingsPanel, BoxLayout.Y_AXIS)
        );

        settingsPanel.setBackground(Color.WHITE);

        settingsPanel.setBorder(
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        );

        // ACCOUNT INFORMATION

        settingsPanel.add(
            createSectionTitle("Account Information")
        );

        JTextField nameField = new JTextField("Photographer Name");
        JTextField emailField = new JTextField("photographer@email.com");
        JTextField phoneField = new JTextField();
        JTextField locationField = new JTextField();

        addField(settingsPanel, "Full Name", nameField);
        addField(settingsPanel, "Email Address", emailField);
        addField(settingsPanel, "Phone Number", phoneField);
        addField(settingsPanel, "Location", locationField);

        JButton saveProfile = createButton("Save Information");

        saveProfile.addActionListener(e -> {

            if (nameField.getText().trim().isEmpty()
                    || emailField.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Name and email are required."
                );

                return;
            }

            JOptionPane.showMessageDialog(
                this,
                "Account information saved for this session."
            );
        });

        settingsPanel.add(saveProfile);

        addSeparator(settingsPanel);

        // CHANGE PASSWORD

        settingsPanel.add(
            createSectionTitle("Change Password")
        );

        JPasswordField currentPassword = new JPasswordField();
        JPasswordField newPassword = new JPasswordField();
        JPasswordField confirmPassword = new JPasswordField();

        addField(settingsPanel, "Current Password", currentPassword);
        addField(settingsPanel, "New Password", newPassword);
        addField(settingsPanel, "Confirm New Password", confirmPassword);

        JButton changePassword = createButton("Update Password");

        changePassword.addActionListener(e -> {

            String newPass = new String(newPassword.getPassword());
            String confirmPass = new String(confirmPassword.getPassword());

            if (currentPassword.getPassword().length == 0
                    || newPass.isEmpty()
                    || confirmPass.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Please fill in all password fields."
                );

                return;
            }

            if (newPass.length() < 6) {

                JOptionPane.showMessageDialog(
                    this,
                    "Password must contain at least 6 characters."
                );

                return;
            }

            if (!newPass.equals(confirmPass)) {

                JOptionPane.showMessageDialog(
                    this,
                    "New passwords do not match."
                );

                return;
            }

            JOptionPane.showMessageDialog(
                this,
                "Password update UI completed. "
                + "Real password authentication will be added with MySQL."
            );

            currentPassword.setText("");
            newPassword.setText("");
            confirmPassword.setText("");
        });

        settingsPanel.add(changePassword);

        addSeparator(settingsPanel);

        // NOTIFICATION SETTINGS

        settingsPanel.add(
            createSectionTitle("Notification Preferences")
        );

        bookingNotifications = new JCheckBox(
            "Receive booking request notifications"
        );

        reviewNotifications = new JCheckBox(
            "Receive new review notifications"
        );

        bookingNotifications.setSelected(true);
        reviewNotifications.setSelected(true);

        settingsPanel.add(bookingNotifications);
        settingsPanel.add(reviewNotifications);

        JButton saveNotifications = createButton(
            "Save Notification Preferences"
        );

        saveNotifications.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                this,
                "Notification preferences saved for this session."
            );
        });

        settingsPanel.add(saveNotifications);

        addSeparator(settingsPanel);

        // PRIVACY SETTINGS

        settingsPanel.add(
            createSectionTitle("Privacy Settings")
        );

        profileVisibility = new JCheckBox(
            "Make my photographer profile visible to clients"
        );

        profileVisibility.setSelected(true);

        settingsPanel.add(profileVisibility);

        JButton savePrivacy = createButton("Save Privacy Settings");

        savePrivacy.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                this,
                "Privacy preferences saved for this session."
            );
        });

        settingsPanel.add(savePrivacy);

        addSeparator(settingsPanel);

        // ACCOUNT ACTIONS

        settingsPanel.add(
            createSectionTitle("Account Management")
        );

        JButton logoutButton = createButton("Logout");

        logoutButton.setBackground(new Color(180, 55, 55));

        logoutButton.addActionListener(e -> {

            int result = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION
            );

            if (result == JOptionPane.YES_OPTION) {

                Window window = SwingUtilities.getWindowAncestor(this);

                if (window != null) {
                    window.dispose();
                }

                new LoginPage().setVisible(true);
            }
        });

        settingsPanel.add(logoutButton);

        JScrollPane scroll = new JScrollPane(settingsPanel);

        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        add(scroll, BorderLayout.CENTER);
    }

    // SECTION HEADING

    private JLabel createSectionTitle(String title) {

        JLabel label = new JLabel(title);

        label.setFont(
            new Font("SansSerif", Font.BOLD, 19)
        );

        label.setForeground(new Color(35, 55, 75));

        label.setBorder(
            BorderFactory.createEmptyBorder(5, 0, 15, 0)
        );

        return label;
    }

    // FORM FIELD

    private void addField(
        JPanel panel,
        String title,
        JComponent field
    ) {

        JLabel label = new JLabel(title);

        label.setFont(
            new Font("SansSerif", Font.BOLD, 13)
        );

        field.setMaximumSize(
            new Dimension(500, 38)
        );

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        panel.add(field);
        panel.add(Box.createVerticalStrut(12));
    }

    // BUTTON DESIGN

    private JButton createButton(String text) {

        JButton button = new JButton(text);

        button.setFont(
            new Font("SansSerif", Font.BOLD, 13)
        );

        button.setForeground(Color.WHITE);
        button.setBackground(new Color(35, 55, 75));

        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);

        button.setAlignmentX(Component.LEFT_ALIGNMENT);

        button.setMaximumSize(
            new Dimension(250, 40)
        );

        button.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );

        return button;
    }

    // SEPARATOR

    private void addSeparator(JPanel panel) {

        panel.add(Box.createVerticalStrut(20));
        panel.add(new JSeparator());
        panel.add(Box.createVerticalStrut(20));
    }
}