package clickcal.ui;

import javax.swing.*;
import java.awt.*;

import clickcal.model.Post;
import clickcal.model.PostData;
import clickcal.utils.UIStyle;

public class FeedPanel extends JPanel {

    private JPanel feed;

    public FeedPanel() {

        setLayout(new BorderLayout());
        setBackground(UIStyle.BACKGROUND);

        feed = new JPanel();
        feed.setLayout(new BoxLayout(feed, BoxLayout.Y_AXIS));
        feed.setBackground(UIStyle.BACKGROUND);

        JPanel createPost = new JPanel(new BorderLayout());
        createPost.setBackground(Color.WHITE);
        createPost.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JLabel heading = new JLabel("Share your photography moments");
        heading.setFont(new Font("SansSerif", Font.BOLD, 17));

        JButton createButton = new JButton("Create Post");

        // Connect Create Post button
        createButton.addActionListener(e -> openCreatePost());

        createPost.add(heading, BorderLayout.CENTER);
        createPost.add(createButton, BorderLayout.EAST);

        feed.add(createPost);
        feed.add(Box.createVerticalStrut(15));

        // Display posts
        refreshFeed();

        JScrollPane scroll = new JScrollPane(feed);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        add(scroll, BorderLayout.CENTER);
    }

    private void openCreatePost() {

        Window window = SwingUtilities.getWindowAncestor(this);

        if (window instanceof JFrame) {
            CreatePost dialog = new CreatePost((JFrame) window);
            dialog.setVisible(true);

            refreshFeed();
        }
    }

    public void refreshFeed() {

        // Keep the Create Post section
        while (feed.getComponentCount() > 2) {
            feed.remove(2);
        }

        for (Post post : PostData.getPosts()) {
            feed.add(new PostCard(post));
            feed.add(Box.createVerticalStrut(15));
        }

        feed.revalidate();
        feed.repaint();
    }
}

