package clickcal.ui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PhotographerPackages extends JPanel {

    private JPanel packagesPanel;

    private final List<PackageInfo> packages = new ArrayList<>();

    public PhotographerPackages() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(243, 242, 239));

        // HEADER

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel heading = new JLabel("My Photography Packages");

        heading.setFont(
            new Font("SansSerif", Font.BOLD, 23)
        );

        JButton addButton = new JButton("+ Create Package");

        addButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        addButton.setBackground(new Color(35, 55, 75));
        addButton.setForeground(Color.WHITE);

        addButton.setOpaque(true);
        addButton.setContentAreaFilled(true);
        addButton.setBorderPainted(false);
        addButton.setFocusPainted(false);

        addButton.setPreferredSize(new Dimension(180, 40));
        addButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        addButton.addActionListener(e -> openCreatePackage());

        header.add(heading, BorderLayout.WEST);
        header.add(addButton, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // PACKAGE LIST

        packagesPanel = new JPanel();

        packagesPanel.setLayout(
            new BoxLayout(packagesPanel, BoxLayout.Y_AXIS)
        );

        packagesPanel.setBackground(
            new Color(243, 242, 239)
        );

        packagesPanel.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JScrollPane scroll = new JScrollPane(packagesPanel);

        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        add(scroll, BorderLayout.CENTER);

        refreshPackages();
    }

    // OPEN PACKAGE FORM

    private void openCreatePackage() {

        JDialog dialog = new JDialog(
            (Frame) SwingUtilities.getWindowAncestor(this),
            "Create Photography Package",
            true
        );

        dialog.setSize(500, 600);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel();

        form.setLayout(
            new BoxLayout(form, BoxLayout.Y_AXIS)
        );

        form.setBackground(Color.WHITE);

        form.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JTextField packageName = new JTextField();
        JTextField price = new JTextField();
        JTextField duration = new JTextField();

        JComboBox<String> category = new JComboBox<>(
            new String[]{
                "Wedding",
                "Birthday",
                "Engagement",
                "Pre-Wedding",
                "Graduation",
                "Maternity",
                "Baby Photography",
                "Corporate",
                "Other"
            }
        );

        JTextArea description = new JTextArea(4, 25);
        description.setLineWrap(true);
        description.setWrapStyleWord(true);

        JTextArea services = new JTextArea(4, 25);
        services.setLineWrap(true);
        services.setWrapStyleWord(true);

        addField(form, "Package Name", packageName);
        addField(form, "Event Category", category);
        addField(form, "Price (INR)", price);
        addField(form, "Duration", duration);

        addField(
            form,
            "Package Description",
            new JScrollPane(description)
        );

        addField(
            form,
            "Included Services",
            new JScrollPane(services)
        );

        JButton saveButton = new JButton("Save Package");

        saveButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        saveButton.setBackground(new Color(35, 55, 75));
        saveButton.setForeground(Color.WHITE);

        saveButton.setOpaque(true);
        saveButton.setContentAreaFilled(true);
        saveButton.setBorderPainted(false);
        saveButton.setFocusPainted(false);

        saveButton.setPreferredSize(new Dimension(180, 42));
        saveButton.setMaximumSize(new Dimension(180, 42));

        saveButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        saveButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        saveButton.addActionListener(e -> {

            String name = packageName.getText().trim();
            String amount = price.getText().trim();
            String time = duration.getText().trim();

            String details = description.getText().trim();
            String included = services.getText().trim();

            if (name.isEmpty() || amount.isEmpty()
                    || time.isEmpty() || details.isEmpty()) {

                JOptionPane.showMessageDialog(
                    dialog,
                    "Please fill in all required fields."
                );

                return;
            }

            double priceValue;

            try {

                priceValue = Double.parseDouble(amount);

                if (priceValue <= 0) {
                    throw new NumberFormatException();
                }

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                    dialog,
                    "Enter a valid price greater than zero."
                );

                return;
            }

            PackageInfo newPackage = new PackageInfo(
                name,
                (String) category.getSelectedItem(),
                priceValue,
                time,
                details,
                included
            );

            packages.add(newPackage);

            refreshPackages();

            dialog.dispose();

            JOptionPane.showMessageDialog(
                this,
                "Photography package created successfully!"
            );
        });

        form.add(Box.createVerticalStrut(15));
        form.add(saveButton);

        JScrollPane formScroll = new JScrollPane(form);
        formScroll.setBorder(null);

        dialog.add(formScroll, BorderLayout.CENTER);

        dialog.setVisible(true);
    }

    // FORM FIELD DESIGN

    private void addField(
        JPanel panel,
        String labelText,
        JComponent field
    ) {

        JLabel label = new JLabel(labelText);

        label.setFont(
            new Font("SansSerif", Font.BOLD, 14)
        );

        field.setMaximumSize(
            new Dimension(450, 90)
        );

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(6));
        panel.add(field);
        panel.add(Box.createVerticalStrut(15));
    }

    // DISPLAY PACKAGES

    private void refreshPackages() {

        packagesPanel.removeAll();

        if (packages.isEmpty()) {

            JLabel empty = new JLabel(
                "You haven't created any photography packages yet."
            );

            empty.setFont(
                new Font("SansSerif", Font.PLAIN, 16)
            );

            packagesPanel.add(empty);

        } else {

            for (PackageInfo info : packages) {

                JPanel card = new JPanel(new BorderLayout(10, 10));

                card.setBackground(Color.WHITE);

                card.setBorder(
                    BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                            new Color(220, 220, 220)
                        ),
                        BorderFactory.createEmptyBorder(
                            20, 20, 20, 20
                        )
                    )
                );

                JLabel name = new JLabel(info.name);

                name.setFont(
                    new Font("SansSerif", Font.BOLD, 20)
                );

                JLabel category = new JLabel(
                    "Category: " + info.category
                );

                JLabel price = new JLabel(
                    "Price: Rs. " + info.price
                );

                price.setFont(
                    new Font("SansSerif", Font.BOLD, 16)
                );

                JLabel duration = new JLabel(
                    "Duration: " + info.duration
                );

                JTextArea details = new JTextArea(
                    info.description
                );

                details.setLineWrap(true);
                details.setWrapStyleWord(true);
                details.setEditable(false);
                details.setBackground(Color.WHITE);

                JTextArea included = new JTextArea(
                    "Included Services:\n" + info.services
                );

                included.setLineWrap(true);
                included.setWrapStyleWord(true);
                included.setEditable(false);
                included.setBackground(Color.WHITE);

                JPanel content = new JPanel();

                content.setBackground(Color.WHITE);

                content.setLayout(
                    new BoxLayout(content, BoxLayout.Y_AXIS)
                );

                content.add(name);
                content.add(Box.createVerticalStrut(8));
                content.add(category);
                content.add(Box.createVerticalStrut(8));
                content.add(price);
                content.add(duration);
                content.add(Box.createVerticalStrut(10));
                content.add(details);
                content.add(Box.createVerticalStrut(10));
                content.add(included);

                card.add(content, BorderLayout.CENTER);

                card.setMaximumSize(
                    new Dimension(Integer.MAX_VALUE, 260)
                );

                packagesPanel.add(card);
                packagesPanel.add(Box.createVerticalStrut(15));
            }
        }

        packagesPanel.revalidate();
        packagesPanel.repaint();
    }

    // PACKAGE DATA

    private static class PackageInfo {

        String name;
        String category;
        double price;
        String duration;
        String description;
        String services;

        PackageInfo(
            String name,
            String category,
            double price,
            String duration,
            String description,
            String services
        ) {

            this.name = name;
            this.category = category;
            this.price = price;
            this.duration = duration;
            this.description = description;
            this.services = services;
        }
    }
}