package clickcal.ui;

import javax.swing.*;
import java.awt.*;

public class RightSidebar extends JPanel {

    public RightSidebar() {

        setPreferredSize(new Dimension(240, 600));

        setBackground(Color.WHITE);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        setBorder(
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        );

        JLabel heading = new JLabel(
            "Discover Photographers"
        );

        heading.setFont(
            new Font("SansSerif", Font.BOLD, 17)
        );

        add(heading);

        add(Box.createVerticalStrut(20));

        String[] photographers = {
            "Demo Photographer 04",
            "Demo Photographer 05",
            "Demo Photographer 06"
        };

        for (String photographer : photographers) {

            JLabel name = new JLabel(photographer);

            JLabel category = new JLabel(
                "Photography | Demo profile"
            );

            category.setForeground(Color.GRAY);

            add(name);

            add(category);

            add(Box.createVerticalStrut(20));
        }

        add(new JSeparator());

        add(Box.createVerticalStrut(20));

        JLabel trending = new JLabel(
            "Trending Categories"
        );

        trending.setFont(
            new Font("SansSerif", Font.BOLD, 17)
        );

        add(trending);

        String[] categories = {
            "Wedding",
            "Birthday",
            "Engagement",
            "Pre-Wedding",
            "Maternity"
        };

        for (String category : categories) {

            JButton button = new JButton(category);

            button.setAlignmentX(Component.LEFT_ALIGNMENT);

            button.setMaximumSize(
                new Dimension(200, 35)
            );

            add(Box.createVerticalStrut(8));

            add(button);
        }
    }
}