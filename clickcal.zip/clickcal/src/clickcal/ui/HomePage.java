package clickcal.ui;

import javax.swing.*;
import java.awt.*;

import clickcal.utils.UIStyle;

public class HomePage extends JFrame {

public HomePage() {

    setTitle("ClickCal - Photography Marketplace");
    setSize(1350, 850);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setLayout(new BorderLayout());

    getContentPane().setBackground(UIStyle.BACKGROUND);

    add(new TopNavigation(), BorderLayout.NORTH);

    JPanel mainPanel = new JPanel(new BorderLayout(15, 0));
    mainPanel.setBackground(UIStyle.BACKGROUND);

    mainPanel.setBorder(
        BorderFactory.createEmptyBorder(20, 25, 20, 25)
    );

    mainPanel.add(new LeftSidebar(), BorderLayout.WEST);
    mainPanel.add(new FeedPanel(), BorderLayout.CENTER);
    mainPanel.add(new RightSidebar(), BorderLayout.EAST);

    add(mainPanel, BorderLayout.CENTER);
}


}
