package clickcal.ui;

import javax.swing.*;
import java.awt.*;

public class PhotographerHomePage extends JFrame {

    private CardLayout cardLayout;
    private JPanel contentPanel;

    public PhotographerHomePage() {

        setTitle("ClickCal - Photographer Workspace");
        setSize(1350, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // TOP NAVIGATION BAR

        JPanel navbar = new JPanel(new BorderLayout());
        navbar.setBackground(Color.WHITE);
        navbar.setPreferredSize(new Dimension(100, 70));

        JLabel logo = new JLabel("  ClickCal");
        logo.setFont(new Font("SansSerif", Font.BOLD, 25));
        logo.setForeground(new Color(35, 55, 75));

        navbar.add(logo, BorderLayout.WEST);

        JPanel navigation = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 15, 20)
        );

        navigation.setBackground(Color.WHITE);

        String[] menus = {
            "Home",
            "My Portfolio",
            "Bookings",
            "Availability"
        };

        for (String menu : menus) {

            JButton button = new JButton(menu);
            styleButton(button);

            button.addActionListener(e -> navigate(menu));

            navigation.add(button);
        }

        navbar.add(navigation, BorderLayout.EAST);
        add(navbar, BorderLayout.NORTH);

        // MAIN LAYOUT

        JPanel main = new JPanel(new BorderLayout(15, 0));
        main.setBackground(new Color(243, 242, 239));

        main.setBorder(
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        // LEFT SIDEBAR

        JPanel sidebar = new JPanel();

        sidebar.setPreferredSize(new Dimension(230, 600));
        sidebar.setBackground(Color.WHITE);

        sidebar.setLayout(
                new BoxLayout(sidebar, BoxLayout.Y_AXIS)
        );

        sidebar.setBorder(
                BorderFactory.createEmptyBorder(20, 15, 20, 15)
        );

        JLabel profile = new JLabel("DEMO PHOTOGRAPHER");

        profile.setFont(
                new Font("SansSerif", Font.BOLD, 17)
        );

        profile.setForeground(new Color(35, 55, 75));

        JLabel specialization = new JLabel(
                "Wedding Photographer"
        );

        specialization.setForeground(Color.GRAY);

        sidebar.add(profile);
        sidebar.add(Box.createVerticalStrut(10));
        sidebar.add(specialization);
        sidebar.add(Box.createVerticalStrut(25));
        sidebar.add(new JSeparator());

        String[] options = {
            "My Profile",
            "My Packages",
            "My Reviews",
            "Settings"
        };

        for (String option : options) {

            JButton button = new JButton(option);

            button.setMaximumSize(new Dimension(200, 40));
            button.setAlignmentX(Component.LEFT_ALIGNMENT);

            styleButton(button);

            button.addActionListener(
                    e -> navigate(option)
            );

            sidebar.add(Box.createVerticalStrut(10));
            sidebar.add(button);
        }

        // CENTRAL CONTENT

        cardLayout = new CardLayout();

        contentPanel = new JPanel(cardLayout);

        contentPanel.setBackground(
                new Color(243, 242, 239)
        );

        // HOME

        contentPanel.add(new FeedPanel(), "Home");

        // PROFILE

        contentPanel.add(
                new PhotographerProfile(),
                "My Profile"
        );

        // PORTFOLIO

        contentPanel.add(
                new PortfolioPage(),
                "My Portfolio"
        );

        // PACKAGES

        contentPanel.add(
                new PhotographerPackages(),
                "My Packages"
        );

        // BOOKINGS

        contentPanel.add(
                new BookingRequests(),
                "Booking Requests"
        );

        // AVAILABILITY

        contentPanel.add(
                new AvailabilityCalendar(),
                "Availability Calendar"
        );

        // REVIEWS

        contentPanel.add(
                new PhotographerReviews(),
                "My Reviews"
        );

        // SETTINGS

        contentPanel.add(
                new PhotographerSettings(),
                "Settings"
        );

        // ADD COMPONENTS TO MAIN LAYOUT

        main.add(sidebar, BorderLayout.WEST);
        main.add(contentPanel, BorderLayout.CENTER);

        add(main, BorderLayout.CENTER);

        } // End of constructor
    // NAVIGATION METHOD

    private void navigate(String page) {

        switch (page) {

            case "Home":
                cardLayout.show(contentPanel, "Home");
                break;

            case "My Profile":
                cardLayout.show(contentPanel, "My Profile");
                break;

            case "My Portfolio":
                cardLayout.show(contentPanel, "My Portfolio");
                break;

            case "My Packages":
                cardLayout.show(contentPanel, "My Packages");
                break;

            case "Bookings":
            case "Booking Requests":
                cardLayout.show(contentPanel, "Booking Requests");
                break;

            case "Availability":
            case "Availability Calendar":
                cardLayout.show(contentPanel, "Availability Calendar");
                break;

            case "My Reviews":
                cardLayout.show(contentPanel, "My Reviews");
                break;

            case "Settings":
                cardLayout.show(contentPanel, "Settings");
                break;
        }
    }

    /*PLACEHOLDER PAGE

    private JPanel createPlaceholder(String title) {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(Color.WHITE);

        panel.setBorder(
                BorderFactory.createEmptyBorder(30, 30, 30, 30)
        );

        JLabel heading = new JLabel(title);

        heading.setFont(
                new Font("SansSerif", Font.BOLD, 25)
        );

        JLabel message = new JLabel(
                "This section will be implemented in the next stage."
        );

        message.setForeground(Color.GRAY);

        JPanel content = new JPanel();

        content.setBackground(Color.WHITE);

        content.setLayout(
                new BoxLayout(content, BoxLayout.Y_AXIS)
        );

        content.add(heading);
        content.add(Box.createVerticalStrut(15));
        content.add(message);

        panel.add(content, BorderLayout.NORTH);

        return panel;
    }*/

    // BUTTON STYLE

    private void styleButton(JButton button) {

        button.setFont(
                new Font("SansSerif", Font.PLAIN, 14)
        );

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);

        button.setBackground(Color.WHITE);
        button.setForeground(new Color(35, 55, 75));

        button.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );
    }
}