package clickcal.ui;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

import clickcal.model.PostData;

public class CreatePost extends JDialog {

private JTextField nameField;
private JTextField specializationField;
private JTextArea captionField;

private JComboBox<String> categoryBox;

private JLabel imagePreview;

private File selectedImage;

public CreatePost(JFrame parent) {

    super(parent, "Create Photography Post", true);

    setSize(600, 720);
    setLocationRelativeTo(parent);

    setLayout(new BorderLayout());

    JPanel form = new JPanel();

    form.setLayout(
        new BoxLayout(form, BoxLayout.Y_AXIS)
    );

    form.setBackground(Color.WHITE);

    form.setBorder(
        BorderFactory.createEmptyBorder(
            25, 35, 25, 35
        )
    );

    // HEADING

    JLabel heading = new JLabel(
        "Create Photography Post"
    );

    heading.setFont(
        new Font("SansSerif", Font.BOLD, 25)
    );

    // PHOTOGRAPHER NAME

    JLabel nameLabel = new JLabel(
        "Photographer Name"
    );

    nameField = new JTextField();

    nameField.setMaximumSize(
        new Dimension(500, 38)
    );

    // SPECIALIZATION

    JLabel specializationLabel = new JLabel(
        "Photography Specialization"
    );

    specializationField = new JTextField();

    specializationField.setMaximumSize(
        new Dimension(500, 38)
    );

    // CAPTION

    JLabel captionLabel = new JLabel(
        "Write Your Caption"
    );

    captionField = new JTextArea(4, 30);

    captionField.setLineWrap(true);

    captionField.setWrapStyleWord(true);

    JScrollPane captionScroll =
        new JScrollPane(captionField);

    captionScroll.setMaximumSize(
        new Dimension(500, 100)
    );

    // CATEGORY

    JLabel categoryLabel = new JLabel(
        "Select Event Category"
    );

    String[] categories = {
        "Wedding",
        "Birthday",
        "Engagement",
        "Pre-Wedding",
        "Graduation",
        "Maternity",
        "Baby",
        "Corporate",
        "Other"
    };

    categoryBox = new JComboBox<>(categories);

    categoryBox.setMaximumSize(
        new Dimension(500, 38)
    );

    // IMAGE UPLOAD

    JButton uploadButton = new JButton(
        "Choose Photograph"
    );

    imagePreview = new JLabel(
        "No Image Selected",
        SwingConstants.CENTER
    );

    imagePreview.setPreferredSize(
        new Dimension(500, 220)
    );

    imagePreview.setMaximumSize(
        new Dimension(500, 220)
    );

    imagePreview.setBorder(
        BorderFactory.createLineBorder(
            new Color(200, 200, 200)
        )
    );

    // PUBLISH BUTTON
    JButton publishButton = new JButton("Publish Post");

    publishButton.setFont(
        new Font("SansSerif", Font.BOLD, 15)
    );

    publishButton.setBackground(new Color(35, 55, 75));
    publishButton.setForeground(Color.WHITE);

    publishButton.setOpaque(true);
    publishButton.setContentAreaFilled(true);
    publishButton.setBorderPainted(false);
    publishButton.setFocusPainted(false);

    publishButton.setAlignmentX(Component.CENTER_ALIGNMENT);

    publishButton.setMaximumSize(
        new Dimension(500, 45)
    );

    publishButton.setPreferredSize(
        new Dimension(500, 45)
    );
    

    // ADD COMPONENTS

    form.add(heading);

    form.add(Box.createVerticalStrut(25));

    form.add(nameLabel);

    form.add(Box.createVerticalStrut(7));

    form.add(nameField);

    form.add(Box.createVerticalStrut(15));

    form.add(specializationLabel);

    form.add(Box.createVerticalStrut(7));

    form.add(specializationField);

    form.add(Box.createVerticalStrut(15));

    form.add(captionLabel);

    form.add(Box.createVerticalStrut(7));

    form.add(captionScroll);

    form.add(Box.createVerticalStrut(15));

    form.add(categoryLabel);

    form.add(Box.createVerticalStrut(7));

    form.add(categoryBox);

    form.add(Box.createVerticalStrut(15));

    form.add(uploadButton);

    form.add(Box.createVerticalStrut(12));

    form.add(imagePreview);

    form.add(Box.createVerticalStrut(20));

    form.add(publishButton);

    // ADD FORM

    add(form, BorderLayout.CENTER);

    // BUTTON ACTIONS

    uploadButton.addActionListener(
        e -> uploadImage()
    );

    publishButton.addActionListener(
        e -> publishPost()
    );
}

// IMAGE UPLOAD METHOD

private void uploadImage() {

    JFileChooser chooser = new JFileChooser();

    chooser.setDialogTitle(
        "Select Your Photography"
    );

    FileNameExtensionFilter filter =
        new FileNameExtensionFilter(
            "Image Files",
            "jpg", "jpeg", "png", "webp"
        );

    chooser.setFileFilter(filter);

    int result = chooser.showOpenDialog(this);

    if (result == JFileChooser.APPROVE_OPTION) {

        selectedImage = chooser.getSelectedFile();

        ImageIcon icon = new ImageIcon(
            selectedImage.getAbsolutePath()
        );

        Image scaled = icon.getImage()
            .getScaledInstance(
                480, 210, Image.SCALE_SMOOTH
            );

        imagePreview.setText("");

        imagePreview.setIcon(
            new ImageIcon(scaled)
        );
    }
}

// PUBLISH POST METHOD

private void publishPost() {

    String name = nameField.getText().trim();

    String specialization =
        specializationField.getText().trim();

    String caption =
        captionField.getText().trim();

    String category =
        (String) categoryBox.getSelectedItem();

    if (name.isEmpty()
            || specialization.isEmpty()
            || caption.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please fill in all the details."
        );

        return;
    }

    if (selectedImage == null) {

        JOptionPane.showMessageDialog(
            this,
            "Please upload a photograph."
        );

        return;
    }

    // STORE POST

    PostData.addPost(
        name,
        specialization,
        caption,
        category,
        selectedImage.getAbsolutePath()
    );

    JOptionPane.showMessageDialog(
        this,
        "Your photography post has been published!"
    );

    dispose();
}


}
