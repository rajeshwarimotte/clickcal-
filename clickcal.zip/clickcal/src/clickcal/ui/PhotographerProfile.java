package clickcal.ui;

import javax.swing.*;
import java.awt.*;

public class PhotographerProfile extends JPanel {

    private JTextField nameField;
    private JTextField specializationField;
    private JTextField locationField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextArea aboutField;

    private JLabel statusLabel;

    public PhotographerProfile() {

        setLayout(new BorderLayout());
        setBackground(new Color(243, 242, 239));

        // PAGE HEADING

        JLabel heading = new JLabel("My Photographer Profile");

        heading.setFont(
            new Font("SansSerif", Font.BOLD, 24)
        );

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        header.add(heading, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // PROFILE FORM

        JPanel form = new JPanel();

        form.setLayout(
            new BoxLayout(form, BoxLayout.Y_AXIS)
        );

        form.setBackground(Color.WHITE);

        form.setBorder(
            BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        nameField = new JTextField();
        specializationField = new JTextField();
        locationField = new JTextField();
        emailField = new JTextField();
        phoneField = new JTextField();

        aboutField = new JTextArea(4, 30);
        aboutField.setLineWrap(true);
        aboutField.setWrapStyleWord(true);

        JScrollPane aboutScroll = new JScrollPane(aboutField);

        aboutScroll.setMaximumSize(
            new Dimension(600, 100)
        );

        addField(form, "Full Name", nameField);
        addField(form, "Photography Specialization", specializationField);
        addField(form, "Location", locationField);
        addField(form, "Email Address", emailField);
        addField(form, "Phone Number", phoneField);
        addField(form, "About Me", aboutScroll);

        // SAVE BUTTON

        JButton saveButton = new JButton("Save Profile");

        saveButton.setBackground(new Color(35, 55, 75));
        saveButton.setForeground(Color.WHITE);
        saveButton.setOpaque(true);
        saveButton.setFocusPainted(false);
        saveButton.setBorderPainted(false);

        saveButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        saveButton.addActionListener(e -> saveProfile());

        form.add(Box.createVerticalStrut(20));
        form.add(saveButton);

        statusLabel = new JLabel(" ");

        statusLabel.setForeground(new Color(0, 130, 70));

        form.add(Box.createVerticalStrut(15));
        form.add(statusLabel);

        JScrollPane scroll = new JScrollPane(form);

        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        add(scroll, BorderLayout.CENTER);
    }

    private void addField(
        JPanel panel,
        String labelText,
        JComponent field
    ) {

        JLabel label = new JLabel(labelText);

        label.setFont(
            new Font("SansSerif", Font.BOLD, 14)
        );

        field.setMaximumSize(
            new Dimension(600, 38)
        );

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(7));
        panel.add(field);
        panel.add(Box.createVerticalStrut(18));
    }

    private void saveProfile() {

        String name = nameField.getText().trim();
        String specialization =
            specializationField.getText().trim();

        String location = locationField.getText().trim();
        String email = emailField.getText().trim();

        if (name.isEmpty()
                || specialization.isEmpty()
                || location.isEmpty()
                || email.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please fill in Name, Specialization, Location and Email."
            );

            return;
        }

        statusLabel.setText(
            "Profile information saved for this session."
        );

        JOptionPane.showMessageDialog(
            this,
            "Profile updated successfully!"
        );
    }
}

