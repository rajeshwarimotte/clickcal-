package clickcal.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

import clickcal.model.AvailabilityData;

public class AvailabilityCalendar extends JPanel {

    private YearMonth currentMonth;
    private JLabel monthLabel;
    private DefaultTableModel tableModel;
    private JTable table;

    private final String[] slots = {
        "Morning", "Afternoon", "Evening"
    };

    private final DateTimeFormatter formatter =
        DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public AvailabilityCalendar() {

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(243, 242, 239));

        currentMonth = YearMonth.now();

        // HEADER

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        );

        monthLabel = new JLabel("", SwingConstants.CENTER);
        monthLabel.setFont(
            new Font("SansSerif", Font.BOLD, 22)
        );

        JButton previous = new JButton("Previous");
        JButton next = new JButton("Next");

        previous.addActionListener(e -> {
            currentMonth = currentMonth.minusMonths(1);
            refreshCalendar();
        });

        next.addActionListener(e -> {
            currentMonth = currentMonth.plusMonths(1);
            refreshCalendar();
        });

        header.add(previous, BorderLayout.WEST);
        header.add(monthLabel, BorderLayout.CENTER);
        header.add(next, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // SCHEDULE TABLE

        String[] columns = {
            "Date", "Morning", "Afternoon", "Evening"
        };

        tableModel = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(45);

        table.setFont(
            new Font("SansSerif", Font.PLAIN, 13)
        );

        JScrollPane scroll = new JScrollPane(table);

        add(scroll, BorderLayout.CENTER);

        // ACTIONS

        JButton updateButton = new JButton("Update Selected Slot");

        updateButton.addActionListener(
            e -> updateAvailability()
        );

        JPanel bottom = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 15, 12)
        );

        bottom.setBackground(Color.WHITE);

        bottom.add(updateButton);

        JLabel legend = new JLabel(
            "Available | Unavailable | Booked"
        );

        bottom.add(legend);

        add(bottom, BorderLayout.SOUTH);

        refreshCalendar();
    }

    // LOAD MONTHLY SCHEDULE

    private void refreshCalendar() {

        tableModel.setRowCount(0);

        monthLabel.setText(
            currentMonth.getMonth() + " "
            + currentMonth.getYear()
        );

        for (int day = 1;
                day <= currentMonth.lengthOfMonth();
                day++) {

            LocalDate date = currentMonth.atDay(day);

            String dateKey = date.format(formatter);

            Object[] row = {
                dateKey,
                AvailabilityData.getStatus(dateKey, "Morning"),
                AvailabilityData.getStatus(dateKey, "Afternoon"),
                AvailabilityData.getStatus(dateKey, "Evening")
            };

            tableModel.addRow(row);
        }
    }

    // UPDATE SELECTED TIME SLOT

    private void updateAvailability() {

        int row = table.getSelectedRow();
        int column = table.getSelectedColumn();

        if (row == -1 || column < 1 || column > 3) {

            JOptionPane.showMessageDialog(
                this,
                "Select a date and a time slot first."
            );

            return;
        }

        String date = tableModel.getValueAt(
            row, 0
        ).toString();

        String slot = slots[column - 1];

        String currentStatus = AvailabilityData.getStatus(
            date, slot
        );

        String[] statuses = {
            "Available", "Unavailable", "Booked"
        };

        String selectedStatus = (String)
            JOptionPane.showInputDialog(
                this,
                "Choose status for " + slot + ":",
                "Update Availability",
                JOptionPane.QUESTION_MESSAGE,
                null,
                statuses,
                currentStatus
            );

        if (selectedStatus != null) {

            AvailabilityData.setStatus(
                date,
                slot,
                selectedStatus
            );

            refreshCalendar();
        }
    }
}