package clickcal.ui;

import clickcal.model.Booking;
import clickcal.model.BookingData;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class BookingRequests extends JPanel {

    private JTable table;
    private DefaultTableModel model;

    public BookingRequests() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 247, 250));

        JLabel title = new JLabel("Booking Requests");

        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 10, 20)
        );

        add(title, BorderLayout.NORTH);

        String[] columns = {
            "Booking ID",
            "Client",
            "Package",
            "Event Date",
            "Time Slot",
            "Location",
            "Status"
        };

        model = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(35);
        table.setFont(new Font("Arial", Font.PLAIN, 13));

        JScrollPane scroll = new JScrollPane(table);

        add(scroll, BorderLayout.CENTER);

        JPanel buttons = new JPanel();

        JButton acceptButton = new JButton("Accept");
        JButton rejectButton = new JButton("Reject");
        JButton refreshButton = new JButton("Refresh");

        buttons.add(acceptButton);
        buttons.add(rejectButton);
        buttons.add(refreshButton);

        add(buttons, BorderLayout.SOUTH);

        acceptButton.addActionListener(
                e -> updateStatus("Confirmed")
        );

        rejectButton.addActionListener(
                e -> updateStatus("Rejected")
        );

        refreshButton.addActionListener(
                e -> loadBookings()
        );

        loadBookings();
    }

    private void loadBookings() {

        model.setRowCount(0);

        for (Booking booking : BookingData.getBookings()) {

            model.addRow(new Object[]{
                booking.getBookingId(),
                booking.getClientName(),
                booking.getPackageName(),
                booking.getEventDate(),
                booking.getTimeSlot(),
                booking.getLocation(),
                booking.getStatus()
            });
        }
    }

    private void updateStatus(String status) {

        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a booking first."
            );

            return;
        }

        int bookingId = (int) model.getValueAt(
                selectedRow, 0
        );

        BookingData.updateStatus(bookingId, status);

        loadBookings();

        JOptionPane.showMessageDialog(
                this,
                "Booking " + status + " successfully!"
        );
    }
}