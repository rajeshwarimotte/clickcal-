package clickcal.ui;

import javax.swing.*;
import java.awt.*;
import java.io.File;

import clickcal.model.Post;

public class PostCard extends JPanel {

    public PostCard(Post post) {

        setLayout(new BorderLayout(10, 15));
        setBackground(Color.WHITE);

        setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(225, 225, 225)
                ),
                BorderFactory.createEmptyBorder(
                    15, 15, 15, 15
                )
            )
        );

        // PHOTOGRAPHER DETAILS

        JLabel name = new JLabel(post.getPhotographer());

        name.setFont(
            new Font("SansSerif", Font.BOLD, 18)
        );

        JLabel specialization = new JLabel(
            post.getSpecialization() + " | DEMO PROFILE"
        );

        specialization.setForeground(Color.GRAY);

        JLabel description = new JLabel(
            "<html><p style='width:500px'>"
            + post.getDescription()
            + "</p></html>"
        );

        JPanel header = new JPanel();

        header.setLayout(
            new BoxLayout(header, BoxLayout.Y_AXIS)
        );

        header.setBackground(Color.WHITE);

        header.add(name);
        header.add(Box.createVerticalStrut(5));
        header.add(specialization);
        header.add(Box.createVerticalStrut(12));
        header.add(description);

        add(header, BorderLayout.NORTH);

        // PHOTOGRAPH DISPLAY

        JLabel imageLabel = new JLabel(
            "Loading photograph...",
            SwingConstants.CENTER
        );

        imageLabel.setPreferredSize(
            new Dimension(550, 350)
        );

        imageLabel.setBackground(
            new Color(245, 245, 245)
        );

        imageLabel.setOpaque(true);

        imageLabel.setBorder(
            BorderFactory.createLineBorder(
                new Color(230, 230, 230)
            )
        );

        String imagePath = post.getImagePath();

        if (imagePath != null && !imagePath.isEmpty()) {

            File imageFile = new File(imagePath);

            if (imageFile.exists()) {

                ImageIcon original = new ImageIcon(
                    imageFile.getAbsolutePath()
                );

                Image scaled = original.getImage()
                    .getScaledInstance(
                        550,
                        350,
                        Image.SCALE_SMOOTH
                    );

                imageLabel.setText("");

                imageLabel.setIcon(
                    new ImageIcon(scaled)
                );

            } else {

                imageLabel.setText(
                    "Photograph not found: " + imagePath
                );
            }

        } else {

            imageLabel.setText("No photograph uploaded");
        }

        add(imageLabel, BorderLayout.CENTER);

        // CATEGORY AND BUTTONS

        JLabel category = new JLabel(
            "Category: " + post.getCategory()
        );

        category.setFont(
            new Font("SansSerif", Font.BOLD, 14)
        );

        JButton likeButton = new JButton("Like");

        JButton commentButton = new JButton("Comment");

        JButton portfolioButton = new JButton("View Portfolio");

        JPanel bottom = new JPanel(
            new BorderLayout()
        );

        bottom.setBackground(Color.WHITE);

        JPanel buttons = new JPanel(
            new FlowLayout(FlowLayout.LEFT)
        );

        buttons.setBackground(Color.WHITE);

        buttons.add(likeButton);
        buttons.add(commentButton);
        buttons.add(portfolioButton);

        bottom.add(category, BorderLayout.NORTH);
        bottom.add(buttons, BorderLayout.SOUTH);

        add(bottom, BorderLayout.SOUTH);

        setPreferredSize(
            new Dimension(700, 500)
        );

        setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 550)
        );
    }
}

